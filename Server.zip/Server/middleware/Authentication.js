const jwt = require('jsonwebtoken')
const validateToken = (req, res, next) => {
    const accessToken = req.header("accessToken");
    
    if (!accessToken) return res.json({ error: "User not logged in" });

else{
        const validToken = jwt.verify(accessToken, 'verySecretValue');
        const user = validToken;
        req.user = user;
        if (validToken) {
            return next();
        }}

}
module.exports = validateToken;