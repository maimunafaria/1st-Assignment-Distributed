const express = require('express')
const validateToken = require("../middleware/Authentication");
const router = express.Router()

const AuthController = require('../controllers/AuthController')

router.post('/register', AuthController.register)
router.post('/login', AuthController.login)
router.get("/", validateToken, async (req, res) => {
    res.json(req.user);
    console.log(req.user);
});

module.exports = router