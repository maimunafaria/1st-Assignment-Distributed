const express = require('express')
const router = express.Router()

const NotificationController = require('../controllers/NotificationController')

router.get('/getNotification', NotificationController.getNotification)
router.post('/createNotification', NotificationController.createNotificationsForUsers);
router.put('/approve', NotificationController.approve)

module.exports = router