const express = require('express')
const multer = require('multer');
const router = express.Router()
const upload = multer({ dest: 'uploads/' });
const PostController = require('../controllers/PostController')

router.post('/post', upload.single('image'), PostController.post)
router.get('/getPost', PostController.getPost)

module.exports = router